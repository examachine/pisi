//
//
// C++ Implementation for module: Graph_Utility
//
// Description: 
//
//
// Author: exa
//
//

#include "Utility.hxx"

namespace Utility {

  int Rand::seed;

}
