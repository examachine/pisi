//
//
// C++ Implementation file for application
//
// Description: includes the main(...) function
//
// exa
//
//

#include "General.hxx"

int main(int argc, char *argv[])
{

    cout << "hello, world" << endl;

    return 0; // success
}
