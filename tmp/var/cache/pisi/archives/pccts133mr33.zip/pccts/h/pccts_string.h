#ifndef __PCCTS_STRING_H__
#define __PCCTS_STRING_H__

#ifdef PCCTS_USE_NAMESPACE_STD
#include <cstring>
#else
#include <string.h>
#endif

#endif
