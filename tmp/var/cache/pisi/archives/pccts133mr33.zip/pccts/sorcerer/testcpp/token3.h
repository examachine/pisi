#define Plus	1
#define Mult	2
#define Var		3
