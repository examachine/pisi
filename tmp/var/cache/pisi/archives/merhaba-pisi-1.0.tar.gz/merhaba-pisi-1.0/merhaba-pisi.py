#!/usr/bin/python
# -*- coding: utf-8 -*-

import os
print "Sana da merhaba %s" % (os.getenv("USER"))
